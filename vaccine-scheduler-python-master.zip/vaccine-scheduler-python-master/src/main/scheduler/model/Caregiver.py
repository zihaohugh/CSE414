import sys

sys.path.append("../util/*")
sys.path.append("../db/*")
from util.Util import Util
from db.ConnectionManager import ConnectionManager
import pymssql


class Caregiver:
    def __init__(self, username, password=None, salt=None, hash=None):
        self.username = username
        self.password = password
        self.salt = salt
        self.hash = hash

    # getters
    def get(self):
        cm = ConnectionManager()
        conn = cm.create_connection()
        cursor = conn.cursor(as_dict=True)

        get_caregiver_details = "SELECT Salt, Hash FROM Caregivers WHERE Username = %s"
        try:
            cursor.execute(get_caregiver_details, self.username)
            for row in cursor:
                curr_salt = row['Salt']
                curr_hash = row['Hash']
                calculated_hash = Util.generate_hash(self.password, curr_salt)
                if not curr_hash == calculated_hash:
                    cm.close_connection()
                    return None
                else:
                    self.salt = curr_salt
                    self.hash = calculated_hash
                    return self
        except pymssql.Error:
            print("Error occurred when getting Caregivers")
            cm.close_connection()

        cm.close_connection()
        return None

    def get_username(self):
        return self.username

    def get_salt(self):
        return self.salt

    def get_hash(self):
        return self.hash

    def save_to_db(self):
        cm = ConnectionManager()
        conn = cm.create_connection()
        cursor = conn.cursor(as_dict=True)

        add_caregivers = "INSERT INTO Caregivers VALUES (%s, %s, %s)"
        try:
            cursor.execute(add_caregivers, (self.username, self.salt, self.hash))
            # you must call commit() to persist your data if you don't set autocommit to True
            conn.commit()
        except pymssql.Error as db_err:
            print("Error occurred when inserting Caregivers")
            sqlrc = str(db_err.args[0])
            print("Exception code: " + str(sqlrc))
            cm.close_connection()
        cm.close_connection()

    # Insert availability with parameter date d
    def upload_availability(self, d):
        cm = ConnectionManager()
        conn = cm.create_connection()
        cursor = conn.cursor(as_dict=True)
        has_appointment = "SELECT ID FROM Appointment WHERE CaregiverName = %s AND Time = %s"
        try:
            cursor.execute(has_appointment, (self.username, d))
            result = []
            for row in cursor:
                result.append(row['ID'])
            if result:
                print("You have appointment on this date! Can not upload new availability!")
                return
        except pymssql.Error:
            print('Fail to check existing appointments!')
            cm.close_connection()

        add_availability = "INSERT INTO Availabilities VALUES (%s , %s)"
        try:
            cursor.execute(add_availability, (d, self.username))
            # you must call commit() to persist your data if you don't set autocommit to True
            conn.commit()
            # if the caregiver has not uploaded availability on the date yet
            print("Your availability uploaded!")
        except pymssql.Error:
            # if the current caregiver has already uploaded availability on the date
            print("Error occurred when updating caregiver availability. You have"
                  " already uploaded availability for this date!")
            cm.close_connection()
        cm.close_connection()

    # search the caregiver schedule
    def search_caregiver_schedule(self, d):
        cm = ConnectionManager()
        conn = cm.create_connection()
        cursor = conn.cursor(as_dict=True)

        search = "SELECT C.Username, V.Doses, V.name AS VaccineName FROM Caregivers AS C, Vaccines AS V," \
                 " Availabilities AS A WHERE C.Username = A.Username AND A.Time = %s"
        try:
            cursor.execute(search, d)
            caregivers = []
            vaccines = {}
            for row in cursor:
                caregiver_name = row['Username']
                dose = row['Doses']
                vaccine = row['VaccineName']
                if caregiver_name not in caregivers:
                    caregivers.append(caregiver_name)
                if vaccine not in vaccines.keys():
                    vaccines[vaccine] = dose
            if not caregivers:
                print("There's no available caregivers on " + str(d))
            elif not vaccines:
                print("There are no available vaccine doses on " + str(d))
            else:
                print("Available caregivers: ")
                for person in caregivers:
                    print(person)
                print()
                print("Available vaccines")
                for one_vaccine in vaccines:
                    print("Name: " + one_vaccine + '    Doses: ' + str(vaccines[one_vaccine]))

        except pymssql.Error:
            print("Error occurred when search caregiver schedule")
            cm.close_connection()
        cm.close_connection()
        return None

    def show_appointments(self):
        cm = ConnectionManager()
        conn = cm.create_connection()
        cursor = conn.cursor(as_dict=True)

        # get the patient username, appointment id and date of the appointment
        appointment = "SELECT PatientName, ID, Time, Vaccine FROM Appointment WHERE CaregiverName = %s"
        result = []
        try:
            cursor.execute(appointment, self.username)
            for row in cursor:
                result.append(row['PatientName'])
                result.append(row['ID'])
                result.append(row['Time'])
                result.append(row['Vaccine'])
            return result
        except:
            print("Error occurred when show appointment")

    def cancel(self, appointment_id):
        cm = ConnectionManager()
        conn = cm.create_connection()
        cursor = conn.cursor(as_dict=True)

        # find if the appointment exists
        check = "SELECT CaregiverName, Time, Vaccine FROM Appointment WHERE ID = %d"
        result = []
        try:
            cursor.execute(check, appointment_id)
            for row in cursor:
                result.append(row['Time'])
                result.append(row['Vaccine'])
                result.append(row['CaregiverName'])
            if not result:
                print("There's no appointment matches this id")
                return
            elif self.username != result[2]:
                print("You can not cancel other people's appointment!")
                return
            else:
                date = result[0]
                vaccine = result[1]
                self.upload_availability(date)
        except pymssql.Error:
            print("Error occurred when finding the appointment")
            cm.close_connection()

        # delete the appointment from the table
        delete = "DELETE FROM Appointment WHERE ID = %d"
        try:
            cursor.execute(delete, appointment_id)
            # you must call commit() to persist your data if you don't set autocommit to True
            conn.commit()
            print("Appointment canceled successfully!")
            return vaccine
        except pymssql.Error:
            print("Error occurred when deleting appointment")
            cm.close_connection()
        cm.close_connection()