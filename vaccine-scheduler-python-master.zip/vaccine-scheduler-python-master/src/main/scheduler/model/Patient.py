import sys
import random

sys.path.append("../util/*")
sys.path.append("../db/*")
from util.Util import Util
from db.ConnectionManager import ConnectionManager
import pymssql


class Patient:
    def __init__(self, username, password=None, salt=None, hash=None):
        self.username = username
        self.password = password
        self.salt = salt
        self.hash = hash

    # getter of patient
    def get(self):
        cm = ConnectionManager()
        conn = cm.create_connection()
        cursor = conn.cursor(as_dict=True)

        get_patient_details = "SELECT Salt, Hash FROM Patients WHERE Username = %s"
        try:
            cursor.execute(get_patient_details, self.username)
            for row in cursor:
                curr_salt = row["Salt"]
                curr_hash = row["Hash"]
                calculated_hash = Util.generate_hash(self.password, curr_salt)
                if not curr_hash == calculated_hash:
                    cm.close_connection()
                    return None
                else:
                    self.salt = curr_salt
                    self.hash = calculated_hash
                    return self
        except pymssql.Error:
            print("Error occurred when getting Patients")
            cm.close_connection()

        cm.close_connection()
        return None

    def get_username(self):
        return self.username

    def get_salt(self):
        return self.salt

    def get_hash(self):
        return self.hash

    def save_to_db(self):
        cm = ConnectionManager()
        conn = cm.create_connection()
        cursor = conn.cursor(as_dict=True)

        add_patients = "INSERT INTO Patients VALUES (%s, %s, %s)"
        try:
            cursor.execute(add_patients, (self.username, self.salt, self.hash))
            # there's no autocommit, so add a commit here
            conn.commit()
        except pymssql.Error as db_err:
            print("Error occurred when inserting Patients")
            sqlrc = str(db_err.args[0])
            print("Exception code: " + str(sqlrc))
            cm.close_connection()
        cm.close_connection()

    # search the caregiver schedule
    def search_caregiver_schedule(self, d):
        cm = ConnectionManager()
        conn = cm.create_connection()
        cursor = conn.cursor(as_dict=True)

        search = "SELECT C.Username, V.Doses, V.name AS VaccineName FROM Caregivers AS C, Vaccines AS V," \
                 " Availabilities AS A WHERE C.Username = A.Username AND A.Time = %s"
        try:
            cursor.execute(search, d)
            caregivers = []
            vaccines = {}
            for row in cursor:
                caregiver_name = row['Username']
                dose = row['Doses']
                vaccine = row['VaccineName']
                if caregiver_name not in caregivers:
                    caregivers.append(caregiver_name)
                if vaccine not in vaccines.keys():
                    vaccines[vaccine] = dose
            if not caregivers:
                print("There's no available caregivers on " + str(d))
            elif not vaccines:
                print("There are no available vaccine doses on " + str(d))
            else:
                print("Available caregivers: ")
                for person in caregivers:
                    print(person)
                print()
                print("Available vaccines")
                for one_vaccine in vaccines:
                    print("Name: " + one_vaccine + '    Doses: ' + str(vaccines[one_vaccine]))
        except pymssql.Error:
            print("Error occurred when search caregiver schedule")
            cm.close_connection()
        cm.close_connection()
        return None

    # reserve for an appointment
    def reserve(self, d, vaccine_name):
        cm = ConnectionManager()
        conn = cm.create_connection()
        cursor = conn.cursor(as_dict=True)

        # find caregivers who are available on the given date
        reserve = "SELECT C.Username FROM Caregivers AS C, Availabilities " \
                  "AS A WHERE A.Username = C.Username AND A.Time = %s"
        cursor.execute(reserve, d)
        result = []
        for row in cursor:
            caregiver_name = row['Username']
            result.append(caregiver_name)
        # there's no available caregiver
        if not result:
            print("There's no available caregiver on the given date!")
        else:
            """# check: find if the current patient has already reserved an appointment on the date
            reserved = "SELECT PatientName FROM Appointment WHERE PatientName = %s AND Time = %s"
            try:
                has_reserved = []
                cursor.execute(reserved, (self.username, d))
                for row in cursor:
                    has_reserved.append(row["PatientName"])
                if has_reserved:
                    print("You have already reserved an appointment on this date!")
                    return None
            except pymssql.Error:
                print("Fail to check if the current patient has already reserved on this date!")"""
            # select a random caregiver for the patient
            caregiver = random.choice(result)
            # save the appointment to db
            add_appointment = "INSERT INTO Appointment (CaregiverName, PatientName, Time, Vaccine) VALUES (%s, %s, %s, %s)"
            # get the appointment id of the appointment
            appointment_detail = "SELECT ID FROM Appointment WHERE CaregiverName = %s"
            try:
                cursor.execute(add_appointment, (caregiver, self.username, d, vaccine_name))
                conn.commit()
                try:
                    cursor.execute(appointment_detail, caregiver)
                    id = None
                    for row in cursor:
                        id = row['ID']
                    # delete the availability of the caregiver
                    delete_availability = "DELETE FROM Availabilities WHERE Username = %s AND Time = %s"
                    cursor.execute(delete_availability, (caregiver, d))
                    conn.commit()
                    # return the appointment id and the name of the caregiver
                    return id, caregiver
                except pymssql.Error:
                    print("Fail to get the appointment id and caregiver's name!")
            except pymssql.Error as db_err:
                print("Error occurred when create appointment")
                sqlrc = str(db_err.args[0])
                print("Exception code: " + str(sqlrc))
                cm.close_connection()
            cm.close_connection()

    def show_appointments(self):
        cm = ConnectionManager()
        conn = cm.create_connection()
        cursor = conn.cursor(as_dict=True)

        # get the patient username, appointment id and date of the appointment
        appointment = "SELECT CaregiverName, ID, Time, Vaccine FROM Appointment WHERE PatientName = %s"
        result = []
        try:
            cursor.execute(appointment, self.username)
            for row in cursor:
                result.append(row['CaregiverName'])
                result.append(row['ID'])
                result.append(row['Time'])
                result.append(row['Vaccine'])
            return result
        except:
            print("Error occurred when show appointment")

    def cancel(self, appointment_id):
        cm = ConnectionManager()
        conn = cm.create_connection()
        cursor = conn.cursor(as_dict=True)

        # find if the appointment exists
        check = "SELECT * FROM Appointment WHERE ID = %d"
        result = []
        try:
            cursor.execute(check, appointment_id)
            for row in cursor:
                result.append(row['CaregiverName'])
                result.append(row['Time'])
                result.append(row['Vaccine'])
                result.append(row['PatientName'])
            if not result:
                print("There's no appointment matches this id")
                return
            elif self.username != result[3]:
                print("You can not cancel other people's appointment!")
                return
            else:
                add_availability = "INSERT INTO Availabilities VALUES (%s , %s)"
                try:
                    cursor.execute(add_availability, (result[1], result[0]))
                    # you must call commit() to persist your data if you don't set autocommit to True
                    conn.commit()
                    vaccine = result[2]
                except pymssql.Error:
                    print("Error occurred when updating caregiver availability")
                    cm.close_connection()
        except pymssql.Error:
            print("Error occurred when finding the appointment")
            cm.close_connection()

        # delete the appointment from the table
        delete = "DELETE FROM Appointment WHERE ID = %d"
        try:
            cursor.execute(delete, appointment_id)
            # you must call commit() to persist your data if you don't set autocommit to True
            conn.commit()
            print("Appointment canceled successfully!")
            return vaccine
        except pymssql.Error:
            print("Error occurred when deleting appointment")
            cm.close_connection()
        cm.close_connection()

    def has_reserved(self, d):
        cm = ConnectionManager()
        conn = cm.create_connection()
        cursor = conn.cursor(as_dict=True)
        # check: find if the current patient has already reserved an appointment on the date
        reserved = "SELECT PatientName FROM Appointment WHERE PatientName = %s AND Time = %s"
        try:
            has_reserved = []
            cursor.execute(reserved, (self.username, d))
            for row in cursor:
                has_reserved.append(row["PatientName"])
            if has_reserved:
                return True
        except pymssql.Error:
            print("Fail to check if the current patient has already reserved on this date!")
        return False
