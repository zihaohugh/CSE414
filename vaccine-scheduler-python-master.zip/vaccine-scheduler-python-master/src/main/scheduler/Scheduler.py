import sys
from model.Vaccine import Vaccine
from model.Caregiver import Caregiver
from model.Patient import Patient
from util.Util import Util
from db.ConnectionManager import ConnectionManager
import pymssql
import datetime
import re


'''
objects to keep track of the currently logged-in user
Note: it is always true that at most one of currentCaregiver and currentPatient is not null
        since only one user can be logged-in at a time
'''
current_patient = None

current_caregiver = None


def create_patient(tokens):
    # part 1
    # create_patient <username> <password>
    # check 1: the length for tokens need to be exactly 3 to include all information (with the operation name)
    if len(tokens) != 3:
        print("please try again!")
        return

    # check 2: if already logged in, can't create
    global current_caregiver
    global current_patient
    if current_caregiver is not None or current_patient is not None:
        print("Can not create new patient when logged in!")
        return

    username = tokens[1]
    password = tokens[2]
    # check 3: check if the username has been taken already
    if username_exists_patient(username):
        print("Username taken, try again!")
        return

    # check 4: if the password is strong
    if not strong_password(password):
        print("The password is not strong enough!")
        print("You need at least 8 characters, with digit, both uppercase and lower case letters\n"
              "and at least one special character, from “!”, “@”, “#”, “?”.")
        return

    salt = Util.generate_salt()
    hash = Util.generate_hash(password, salt)

    # create the patient
    try:
        patient = Patient(username, salt=salt, hash=hash)
        # save to caregiver information to our database
        try:
            patient.save_to_db()
            current_caregiver = None
            current_patient = patient
        except:
            print("Create failed, Cannot save")
            return
        print(" *** Account created successfully *** ")
        print("Patient logged in as: " + username)
    except pymssql.Error:
        print("Create failed")
        return


def username_exists_patient(username):
    cm = ConnectionManager()
    conn = cm.create_connection()

    select_username = "SELECT * FROM Patients WHERE Username = %s"
    try:
        cursor = conn.cursor(as_dict=True)
        cursor.execute(select_username, username)
        #  returns false if the cursor is not before the first record or if there are no rows in the ResultSet.
        for row in cursor:
            return row['Username']
    except pymssql.Error:
        print("Error occurred when checking username")
        cm.close_connection()
    cm.close_connection()
    return False


def create_caregiver(tokens):
    # create_caregiver <username> <password>
    # check 1: the length for tokens need to be exactly 3 to include all information (with the operation name)
    if len(tokens) != 3:
        print("Please try again!")
        return

    # check 2: if already logged in, can't create
    global current_caregiver
    global current_patient
    if current_caregiver is not None or current_patient is not None:
        print("Can not create new caregiver when logged in!")
        return

    username = tokens[1]
    password = tokens[2]
    # check 3: check if the username has been taken already
    if username_exists_caregiver(username):
        print("Username taken, try again!")
        return

    # check 4: if the password is strong
    if not strong_password(password):
        print("The password is not strong enough!")
        print("You need at least 8 characters, with digit, both uppercase and lower case letters\n"
              "and at least one special character, from “!”, “@”, “#”, “?”.")
        return

    salt = Util.generate_salt()
    hash = Util.generate_hash(password, salt)

    # create the caregiver
    try:
        caregiver = Caregiver(username, salt=salt, hash=hash)
        # save to caregiver information to our database
        try:
            caregiver.save_to_db()
            current_patient = None
            current_caregiver = caregiver
        except:
            print("Create failed, Cannot save")
            return
        print(" *** Account created successfully *** ")
        print("Caregiver logged in as: " + username)
    except pymssql.Error:
        print("Create failed")
        return


def username_exists_caregiver(username):
    cm = ConnectionManager()
    conn = cm.create_connection()

    select_username = "SELECT * FROM Caregivers WHERE Username = %s"
    try:
        cursor = conn.cursor(as_dict=True)
        cursor.execute(select_username, username)
        #  returns false if the cursor is not before the first record or if there are no rows in the ResultSet.
        for row in cursor:
            return row['Username']
    except pymssql.Error:
        print("Error occurred when checking username")
        cm.close_connection()
    cm.close_connection()
    return False


def login_patient(tokens):
    # login_patient <username> <password>
    # check 1: if someone's already logged-in, they need to log out first
    global current_patient
    if current_patient is not None or current_caregiver is not None:
        print("Already logged in!")
        return

    # check 2: the length for tokens need to be exactly 3 to include all information (with the operation name)
    if len(tokens) != 3:
        print("Please try again!")
        return

    username = tokens[1]
    password = tokens[2]

    patient = None
    try:
        try:
            patient = Patient(username, password=password).get()
        except:
            print("Get Failed")
            return
    except pymssql.Error:
        print("Error occurred when logging in")

    # check if the login was successful
    if patient is None:
        print("Please try again! Make sure the username exists and match the password!")
    else:
        print("Patient logged in as: " + username)
        current_patient = patient


def login_caregiver(tokens):
    # login_caregiver <username> <password>
    # check 1: if someone's already logged-in, they need to log out first
    global current_caregiver
    if current_caregiver is not None or current_patient is not None:
        print("Already logged-in!")
        return

    # check 2: the length for tokens need to be exactly 3 to include all information (with the operation name)
    if len(tokens) != 3:
        print("Please try again!")
        return

    username = tokens[1]
    password = tokens[2]

    caregiver = None
    try:
        try:
            caregiver = Caregiver(username, password=password).get()
        except:
            print("Get Failed")
            return
    except pymssql.Error:
        print("Error occurred when logging in")

    # check if the login was successful
    if caregiver is None:
        print("Please try again! Make sure the username exists and match the password!")
    else:
        print("Caregiver logged in as: " + username)
        current_caregiver = caregiver


def search_caregiver_schedule(tokens):
    # check 1: check if someone has logged in
    if current_caregiver is None and current_patient is None:
        print("Please login as a patient or a caregiver first!")
        return

    # search_caregiver_schedule <date>
    # check 2: check if the length of the tokens is 2(including the operation information)
    if len(tokens) != 2:
        print("Please try again!")
        return

    date = tokens[1]
    # assume input is hyphenated in the format mm-dd-yyyy
    # check 3: check if the date is valid
    if not is_valid(date):
        print("Please input a valid date in 'mm-dd-yyyy' format!")
        return
    date_tokens = date.split("-")
    month = int(date_tokens[0])
    day = int(date_tokens[1])
    year = int(date_tokens[2])
    try:
        d = datetime.datetime(year, month, day)
        # check 3: find who is logging in to search for the schedule of caregivers
        if current_caregiver is not None:
            current_caregiver.search_caregiver_schedule(d)
        else:
            current_patient.search_caregiver_schedule(d)
    except ValueError:
        print("Please enter a valid date!")
    except pymssql.Error as db_err:
        print("Error occurred when search caregiver schedule")


def reserve(tokens):
    # reserve <date> <vaccine>
    # check 1: check if someone has logged in
    if current_caregiver is None and current_patient is None:
        print("Please login as a patient or a caregiver first!")
        return

    # check 2: check if the current user is patient
    if current_caregiver is not None:
        print("Only patient can reserve!")
        return
    # check 3: check if the length of tokens is 3(include operation information)
    if len(tokens) != 3:
        print('Please try again!')
        return

    # get the date
    date = tokens[1]
    # assume input is hyphenated in the format mm-dd-yyyy
    # check 3: check if the date is valid
    if not is_valid(date):
        print("Please input a valid date in 'mm-dd-yyyy' format!")
        return
    date_tokens = date.split("-")
    month = int(date_tokens[0])
    day = int(date_tokens[1])
    year = int(date_tokens[2])
    d = datetime.datetime(year, month, day)
    # get the vaccine
    vaccine_name = tokens[2]

    # check 4: if the current patient has already reserved on the date
    if current_patient.has_reserved(date):
        print("You have already reserved an appointment on this date!")
        return

    # check 4: check if the vaccine has available doses
    vaccine = None
    try:
        vaccine = Vaccine(vaccine_name, 0).get()
        vaccine.decrease_available_doses(1)
    except ValueError:
        print("There's no available doses for '" + vaccine_name + "'")
        return
    except pymssql.Error:
        print("Error occurred when checking doses")

    # check 5: if getter return null, it means that there's no vaccine with name given
    if vaccine is None:
        print("There's no vaccine named " + str(vaccine_name))
    else:
        # if the vaccine is not null, it means the vaccine exists in the table
        try:
            # assign a caregiver who is available
            try:
                appointment = current_patient.reserve(d, vaccine_name)
                if appointment is not None:
                    print("Appointment ID " + str(appointment[0]))
                    print("Caregiver name: " + appointment[1])
            except ValueError:
                print("Please enter a valid date!")
            except pymssql.Error as db_err:
                print("Error occurred when reserve")
        except pymssql.Error:
            print("Error occurred when decreasing doses")


def upload_availability(tokens):
    #  upload_availability <date>
    #  check 1: check if the current logged-in user is a caregiver
    global current_caregiver
    if current_caregiver is None:
        print("Please login as a caregiver first!")
        return

    # check 2: the length for tokens need to be exactly 2 to include all information (with the operation name)
    if len(tokens) != 2:
        print("Please try again!")
        return

    date = tokens[1]
    # assume input is hyphenated in the format mm-dd-yyyy
    # check 3: check if the date is valid
    if not is_valid(date):
        print("Please input a valid date in 'mm-dd-yyyy' format!")
        return

    date_tokens = date.split("-")
    month = int(date_tokens[0])
    day = int(date_tokens[1])
    year = int(date_tokens[2])
    try:
        d = datetime.datetime(year, month, day)
        try:
            current_caregiver.upload_availability(d)
        except:
            print("Upload Availability Failed")
    except ValueError:
        print("Please enter a valid date!")
    except pymssql.Error as db_err:
        print("Error occurred when uploading availability")


def cancel(tokens):
    """
    TODO: Extra Credit
    """
    # cancel <appointment_id>
    # check 1: check if someone has logged in
    if current_caregiver is None and current_patient is None:
        print("Please login as a patient or a caregiver first!")
        return

    # check 2: check if the length of the tokens is 2(including the operation information)
    if len(tokens) != 2:
        print("Please try again!")
        return

    # get the appointment id
    appointment_id = int(tokens[1])
    vaccine = None
    try:
        if current_caregiver is not None:
            vaccine = current_caregiver.cancel(appointment_id)
        else:
            vaccine = current_patient.cancel(appointment_id)
        try:
            if vaccine is not None:
                cancel_vaccine = Vaccine(vaccine, 0).get()
                cancel_vaccine.increase_available_doses(1)
        except:
            print("Error occurred when add the canceled vaccine doses")
    except pymssql.Error as db_err:
        print("Error occurred when cancel appointment")


def add_doses(tokens):
    #  add_doses <vaccine> <number>
    #  check 1: check if the current logged-in user is a caregiver
    global current_caregiver
    if current_caregiver is None:
        print("Please login as a caregiver first!")
        return

    #  check 2: the length for tokens need to be exactly 3 to include all information (with the operation name)
    if len(tokens) != 3:
        print("Please try again!")
        return

    vaccine_name = str(tokens[1])
    #  check 3: if the current user input a number
    if not (tokens[2].isdigit() or (tokens[2].split('-')[-1].isdigit() and tokens[2].rfind('-') == 0)):
        print("Please input a whole number!")
        return
    doses = int(tokens[2])
    vaccine = None
    try:
        try:
            vaccine = Vaccine(vaccine_name, doses).get()
        except:
            print("Failed to get Vaccine!")
            return
    except pymssql.Error:
        print("Error occurred when adding doses")

    # check 3: if getter returns null, it means that we need to create the vaccine and insert it into the Vaccines
    #          table

    if vaccine is None:
        try:
            vaccine = Vaccine(vaccine_name, doses)
            try:
                vaccine.save_to_db()
                print("New vaccine added!")
            except:
                print("Failed To Save")
                return
        except pymssql.Error:
            print("Error occurred when adding doses")
    else:
        # if the vaccine is not null, meaning that the vaccine already exists in our table
        try:
            try:
                    vaccine.increase_available_doses(doses)
            except:
                print("Failed to increase available doses! Do not add negative doses!")
                return
        except pymssql.Error:
            print("Error occurred when adding doses")

    print("Doses updated!")


def show_appointments(tokens):
    # show_appointments
    # check 1: check if someone has logged in
    if current_caregiver is None and current_patient is None:
        print("Please login as a patient or a caregiver first!")
        return
    try:
        # check 2: find who is logged in(caregiver or patient)
        result = None
        if current_caregiver is not None:
            result = current_caregiver.show_appointments()
        else:
            result = current_patient.show_appointments()
        if not result:
            print("There's no appointment for current user!")
        else:
            i = 0
            while i < len(result):
                print("Partner Name: " + result[i])
                print("Appointment ID: " + str(result[i+1]))
                print("Date: " + str(result[i+2]))
                print("Vaccine name: " + result[i+3])
                print()
                i += 4
    except pymssql.Error as db_err:
        print("Error occurred when search caregiver schedule")


def is_valid(date):
    try:
        datetime.datetime.strptime(date, "%m-%d-%Y")
        return 1
    except:
        return 0


def strong_password(password):
    pattern = re.compile("^(?=.*\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[!@#?])[\da-zA-Z\W]{8,}$")
    return pattern.match(password)


def logout(tokens):
    global current_caregiver
    global current_patient
    current_patient = None
    current_caregiver = None
    print("logout successfully!")


def start():
    stop = False
    while not stop:
        print()
        print(" *** Please enter one of the following commands *** ")
        print("> create_patient <username> <password>")  # //TODO: implement create_patient (Part 1)
        print("> create_caregiver <username> <password>")
        print("> login_patient <username> <password>")  #// TODO: implement login_patient (Part 1)
        print("> login_caregiver <username> <password>")
        print("> search_caregiver_schedule <date>")  #// TODO: implement search_caregiver_schedule (Part 2)
        print("> reserve <date> <vaccine>") #// TODO: implement reserve (Part 2)
        print("> upload_availability <date>")
        print("> cancel <appointment_id>") #// TODO: implement cancel (extra credit)
        print("> add_doses <vaccine> <number>")
        print("> show_appointments")  #// TODO: implement show_appointments (Part 2)
        print("> logout") #// TODO: implement logout (Part 2)
        print("> Quit")
        print()
        response = ""
        print("> Enter: ", end='')

        try:
            response = str(input())
        except ValueError:
            print("Type in a valid argument")
            break

        # response = response.lower()

        tokens = response.split(" ")
        if len(tokens) == 0:
            ValueError("Try Again")
            continue
        operation = tokens[0]
        if operation == "create_patient":
            create_patient(tokens)
        elif operation == "create_caregiver":
            create_caregiver(tokens)
        elif operation == "login_patient":
            login_patient(tokens)
        elif operation == "login_caregiver":
            login_caregiver(tokens)
        elif operation == "search_caregiver_schedule":
            search_caregiver_schedule(tokens)
        elif operation == "reserve":
            reserve(tokens)
        elif operation == "upload_availability":
            upload_availability(tokens)
        elif operation == "cancel":
            cancel(tokens)
        elif operation == "add_doses":
            add_doses(tokens)
        elif operation == "show_appointments":
            show_appointments(tokens)
        elif operation == "logout":
            logout(tokens)
        elif operation == "quit":
            print("Thank you for using the scheduler, Goodbye!")
            stop = True
        else:
            print("Invalid Command")


if __name__ == "__main__":
    '''
    // pre-define the three types of authorized vaccines
    // note: it's a poor practice to hard-code these values, but we will do this ]
    // for the simplicity of this assignment
    // and then construct a map of vaccineName -> vaccineObject
    '''

    # start command line
    print()
    print("Welcome to the COVID-19 Vaccine Reservation Scheduling Application!")

    start()
